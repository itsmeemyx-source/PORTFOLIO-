const button = document.getElementById("exploreBtn");

button.addEventListener("click", () => {

    alert("Welcome to my creative portfolio ✦");

});